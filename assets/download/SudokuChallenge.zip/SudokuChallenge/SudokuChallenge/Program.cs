﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace SudokuChallenge
{
    class Program
    {
        public static List<List<string>> verticalLines = new List<List<string>>();
        public static List<List<string>> horizontalLines = new List<List<string>>();
        public static List<List<string>> boxLines = new List<List<string>>();

        static void Main(string[] args)
        {
            // Create fileName that should be passed as an argument
            var fileName = String.Empty;

            // If no argument passed, check again for possible filename
            if(args.Length == 0)
            {
                Console.WriteLine("Input file name without extension and press <ENTER>: ");
                fileName = Console.ReadLine();
            }
            else
            {
                fileName = args[0];
            }

            try
            {
                // Assuming the file will be within the same directory as the .exe -- Also assuming only the name will be provided as an argument
                using (StreamReader reader = new StreamReader($"{fileName}.txt"))
                {
                    string line = String.Empty;
                    while ((line = reader.ReadLine()) != null)
                    {
                        horizontalLines.Add(line.Split(' ').ToList());
                        if (ValidLine(horizontalLines.Last()) && horizontalLines.Count() < 10)
                        {
                            for (int i = 0; i < 9; i++)
                            {
                                // Create 9 Vertical Lines and 9 Box Lines
                                if (horizontalLines.Count == 1)
                                {
                                    verticalLines.Add(new List<string>());
                                    boxLines.Add(new List<string>());
                                }

                                // Build the columns while reading each row
                                verticalLines[i].Add(horizontalLines.Last()[i]);
                            }

                            // build each box while reading the file. I am sure there is a clearner way to do this...
                            if (horizontalLines.Count() <= 3)
                            {
                                boxLines[0].InsertRange(boxLines[0].Count(), horizontalLines.Last().GetRange(0, 3));
                                boxLines[1].InsertRange(boxLines[1].Count(), horizontalLines.Last().GetRange(3, 3));
                                boxLines[2].InsertRange(boxLines[2].Count(), horizontalLines.Last().GetRange(6, 3));
                            }
                            else if (horizontalLines.Count() <= 6)
                            {
                                boxLines[3].InsertRange(boxLines[3].Count(), horizontalLines.Last().GetRange(0, 3));
                                boxLines[4].InsertRange(boxLines[4].Count(), horizontalLines.Last().GetRange(3, 3));
                                boxLines[5].InsertRange(boxLines[5].Count(), horizontalLines.Last().GetRange(6, 3));
                            }
                            else if (horizontalLines.Count() <= 9)
                            {
                                boxLines[6].InsertRange(boxLines[6].Count(), horizontalLines.Last().GetRange(0, 3));
                                boxLines[7].InsertRange(boxLines[7].Count(), horizontalLines.Last().GetRange(3, 3));
                                boxLines[8].InsertRange(boxLines[8].Count(), horizontalLines.Last().GetRange(6, 3));
                            }
                        }
                        else
                        {
                            // Either a row is invalid or the file is too long
                            ExitWithMessage(false);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("File could not be read:");
                Console.WriteLine(e.Message);
                Console.WriteLine("-- Please check that the test file is included in the same directory and you are only passing the name of the file as the argument. Please do not include the extension.");
                Console.ReadLine();
                Environment.Exit(0);
            }

            // Testing each column for validity
            foreach (List<string> lineTest in verticalLines)
            {
                if (!ValidLine(lineTest))
                {
                    ExitWithMessage(false);
                }
            }

            // Testing each box for validity
            foreach (List<string> lineTest in boxLines)
            {
                if (!ValidLine(lineTest))
                {
                    ExitWithMessage(false);
                }
            }

            // The only way for this application to get here is to pass all validity tests above.
            ExitWithMessage(true);
        }

        public static bool ValidLine(List<string> line)
        {
            if (line.Distinct().Count() == line.Count() && line.Max() == "9" && line.Min() == "1")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static void ExitWithMessage(bool result)
        {
            if(result)
            {
                Console.WriteLine("Yes, valid");
            }
            else
            {
                Console.WriteLine("No, invalid");    
            }

            // Wait for user acknowledgement (to help with running this application as a new command window)
            Console.ReadLine();
            Environment.Exit(0);
        }
    }
}
